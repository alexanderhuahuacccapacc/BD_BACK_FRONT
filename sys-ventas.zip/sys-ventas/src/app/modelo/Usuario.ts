export interface Usuario{
  idUsuario: number;
  user: string;
  estado: string;
  token: string;
}
