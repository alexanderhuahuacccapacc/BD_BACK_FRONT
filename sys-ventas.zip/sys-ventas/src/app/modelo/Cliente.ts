export class Cliente {
  constructor(
   public  dniruc: string,
   public  nombres: string,
   public  repLegal: string,
   public  tipoDocumento: string,
   public  direccion: string,
  ) {}

}
