export class Categoria {
  constructor(
   public idCategoria: number,
   public nombre: string
  ) {
  }
}
