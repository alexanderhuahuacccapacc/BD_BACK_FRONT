export class UnidadMedida {
constructor(
  public idUnidad: number,
  public nombreMedida: string
) {
}
}
