export class Marca {
  constructor(
   public idMarca: number,
   public nombre: string
  ) {}
}
