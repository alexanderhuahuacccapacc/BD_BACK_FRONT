export class Acceso{
  constructor(
   public idAcceso: number,
   public nombre: string,
   public url: string,
   public icono: string
  ) {}
 }
