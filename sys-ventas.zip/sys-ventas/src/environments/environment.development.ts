export const environment = {
  HOST: "http://172.22.2.50:6161",
  RETRY: 2,
  TOKEN_NAME: 'access_token',
  DATA_USERLOGIN: '0'
};
